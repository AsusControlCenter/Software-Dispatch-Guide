/*++

INTEL CONFIDENTIAL
Copyright 2009-2018 Intel Corporation All Rights Reserved.

The source code contained or described herein and all documents
related to the source code ("Material") are owned by Intel Corporation
or its suppliers or licensors. Title to the Material remains with
Intel Corporation or its suppliers and licensors. The Material
contains trade secrets and proprietary and confidential information of
Intel or its suppliers and licensors. The Material is protected by
worldwide copyright and trade secret laws and treaty provisions. No
part of the Material may be used, copied, reproduced, modified,
published, uploaded, posted, transmitted, distributed, or disclosed in
any way without Intel's prior express written permission.

No license under any patent, copyright, trade secret or other
intellectual property right is granted to or conferred upon you by
disclosure or delivery of the Materials, either expressly, by
implication, inducement, estoppel or otherwise. Any license under such
intellectual property rights must be express and approved by Intel in
writing.

File Name:
   fwudef.h

--*/

#ifndef _FWUDEF_H_
#define _FWUDEF_H_

typedef UINT32 uint32_t;

typedef uint32_t STATUS;

typedef struct __UUID
{
   unsigned int   Data1;
   unsigned short Data2;
   unsigned short Data3;
   unsigned char  Data4[8];
} _UUID;

typedef struct {
    UINT16 Major;
    UINT16 Minor;
    UINT16 Hotfix;
    UINT16 Build;
} FWVersion;

typedef struct {
    FWVersion code;
    FWVersion rcvy;
} FlashVersion;


#define MAXIMUM_IPU_SUPPORTED          20

typedef struct version
{
   UINT16      Major;
   UINT16      Minor;
   UINT16      Hotfix;
   UINT16      Build;
}version;

typedef struct _PT_ATTRB
{
   uint32_t PtNameId;
   uint32_t LoadAddress;   // Load Address of the IPU
   version  FwVer;         // FW version from IUP Manifest
   uint32_t CurrentInstId; // Current Inst ID from flash, 0 indicate invalid ID 
   uint32_t CurrentUpvVer; // Upper sig 16 bits are Major Version.
   uint32_t ExpectedInstId;// Expected Inst ID that need to be updated to
   uint32_t ExpectedUpvVer;// Upper sig 16 bits are Major Version.
   uint32_t Resv[4];
}PT_ATTRB;

typedef struct _FWU_GET_IPU_PT_ATTRB_MSG_REPLY
{
   uint32_t MessageType;      // Internal FWU tool use only
   STATUS   Status;           // Internal FWU tool use only
   version  FtpFwVer;         // FW version in Fault Tolerance Partition. 
                              // This might be used for diagnostic or debug.
   uint32_t SizeoOfPtAttrib;  // Size in bytes. Simply is the sizeof (PT_ATTRB structure)
   uint32_t NumOfPartition;   // Number of partition actually return in this reply message
   PT_ATTRB PtAttribute[MAXIMUM_IPU_SUPPORTED];
   uint32_t Resv[4];
}FWU_GET_IPU_PT_ATTRB_MSG_REPLY;

typedef struct _FWU_INFO_FLAGS
{
   uint32_t RecoveryMode:2;   // 0 = No recovery; 1 = Full Recovery Mode,2 = Partial Recovery Mode
   uint32_t IpuNeeded:1;      // IPU_NEEDED bit, if set we are in IPU_NEEDED state.
   uint32_t FwInitDone:1;     // If set indicate FW is done initialized
   uint32_t FwuInProgress:1;  // If set FWU is in progress, this will be set for IFU update as well
   uint32_t SuInprogress:1;   // If set IFU Safe FW update is in progress. 
   uint32_t NewFtTestS:1;     // If set indicate that the new FT image is in Test Needed state (Stage 2 Boot)
   uint32_t SafeBootCnt:4;    // Boot count before the operation is success
   uint32_t FsbFlag:1;        // Force Safe Boot Flag, when this bit is set, we'll boot kernel only and go into recovery mode   

   //////////////////////////////////////////////////////
   // These fields below are important for FWU tool. 
   //////////////////////////////////////////////////////
   uint32_t LivePingNeeded:1; // Use for IFU only, See Below  
                                  // FWU tool needs to send Live-Ping or perform querying to confirm update successful.
                                  // With the current implementation when LivePingNeeded is set, 
                                  // Kernel had already confirmed it. No action from the tool is needed.
   uint32_t ResumeUpdateNeeded:1; // Use for IFU only, If set FWU tool needs to resend update image
   uint32_t RollbackNeededMode:2; // FWU_ROLLBACK_NONE = 0, FWU_ROLLBACK_1, FWU_ROLLBACK_2 
                                      // If not FWU_ROLLBACK_NONE, FWU tool needs to send restore_point image. 
   uint32_t ResetNeeded:2;    // When this field is set to ME_RESET_REQUIRED, FW Kernel will
                                  // perform ME_RESET after this message. No action from the tool is needed.
   uint32_t SuState:4;        // See possible values below
   uint32_t RecoveryCause:2;  // IMAGE_CODE_INVALID = 1; IMAGE_NFT_INVALID = 2;
   uint32_t Reserve:8;
}FWU_INFO_FLAGS;

typedef enum _FWU_OPERATION
{
   FWU_FULL_UPDATE_OPERATION = 0,
   FWU_IPU_UPDATE_OPERATION
}FWU_OPERATION;

typedef enum _FWU_ENVIRONMENT
{
   FWU_ENV_MANUFACTURING = 0,   // Manufacturing update
   FWU_ENV_IFU,                 // Independent Firmware update
}FWU_ENVIRONMENT;

#define FPT_PARTITION_NAME_RBEP         0x50454252 /**< "RBEP" Rom Boot Extension Partition Name */
#define FPT_PARTITION_NAME_FTPR         0x52505446 /**< "FTPR" Fault Tolerant Partition Name*/
#define FPT_PARTITION_NAME_NFTP         0x5054464E /**< "NFTP" Non-Fault Tolerant Partition Name */  
#define FPT_PARTITION_NAME_WCOD         0x444f4357 /**< "WCOD" Partition Name */
#define FPT_PARTITION_NAME_LOCL         0x4C434F4C /**< "LOCL" Partition Name */
#define FPT_PARTITION_NAME_ISHC         0x43485349 /**< "ISHC" Partition Name*/
#define FPT_PARTITION_NAME_PMCP         0x50434D50 /**< "PMCP" Partition Name*/
#define FPT_PARTITION_NAME_OEMP         0x504D454F /**< "OEMP" Partition Name*/
#define FPT_PARTITION_NAME_IUNP         0x504E5549 /**< "IUNP" Partition Name*/
#define FPT_PARTITION_NAME_IOMP         0x504D4F49 /**< "IOMP" Partition Name*/
#define FPT_PARTITION_NAME_MGPP         0x5050474D /**< "MGPP" Partition Name*/
#define FPT_PARTITION_NAME_TBTP         0x50544254 /**< "TBTP" Partition Name*/
#define FPT_PARTITION_NAME_DPHY         0x59485044 /**< "DPHY" Partition Name */

#define   STATUS_UPDATE_SUCCESS                                               0x000
#define   STATUS_UPDATE_IMAGE_INVALID                                         0x201
#define   STATUS_UPDATE_INTEGRITY_FAILURE                                     0x202
#define   STATUS_UPDATE_SKU_MISMATCH                                          0x203
#define   STATUS_UPDATE_FW_VERSION_MISMATCH                                   0x204
#define   STATUS_UPDATE_GENERAL_FAILURE                                       0x205
#define   STATUS_UPDATE_OUT_OF_RESOURCES                                      0x206
#define   STATUS_UPDATE_AUDIT_POLICY_FAILURE                                  0x207
#define   STATUS_UPDATE_ERROR_CREATING_FT                                     0x208
#define   STATUS_UPDATE_SAL_NOTIFICATION_ERROR                                0x209
#define   STATUS_UPDATE_NOT_READY                                             0x213
#define   STATUS_UPDATE_HOST_RESET_REQUIRED                                   0x214
#define   STATUS_INVALID_OEM_ID                                               0x216
#define   STATUS_UPDATE_IMAGE_BLACKLISTED                                     0x217
#define   STATUS_DOWNGRADE_NOT_ALLOWED_SVN_RESTRICTION                        0x23B
#define   STATUS_DOWNGRADE_NOT_ALLOWED_VCN_RESTRICTION                        0x23C
#define   STATUS_UPDATE_INVALID_UPDATE_IMAGE                                  0x2C9

enum errorValues {
    FWU_ERROR_SUCCESS,
    FWU_IME_NO_DEVICE = 8193,
    FWU_UPD_VER_MIS   = 8199,
    FWU_VER_GET_ERR = 8204,
    FWU_CERT_ERR = 8213,
    FWU_REBOOT_NEEDED = 8703,
    FWU_SKU_MISMATCH,
    FWU_VER_MISMATCH,
    FWU_SGN_MISMATCH,
    FWU_GENERAL,
    FWU_UPD_PROCESS,
    FWU_NO_MEMORY = 8710,
    FWU_AUTH = 8712,
    FWU_IMG_HEADER,
    FWU_FILE_OPEN,
    FWU_HTTP_ERROR,
    FWU_USAGE_ERROR,
    FWU_HOSTNAME,
    FWU_UPDATE_TIMEOUT,
    FWU_LOCAL_DIS,
    FWU_SECURE_DIS,
    FWU_IME_UN_SUP_MESS = 8722,
    FWU_NO_UPDATE,
    FWU_IME_NOT_READY,
    FWU_LAST_STATUS,
    FWU_GET_VER_ERR = 8727,
    FWU_IME_SMALL_BUFF,
    FWU_WSMAN_NO = 8734,
    FWU_UNSUPPRT_OS = 8740,
    FWU_ERROR_FW,
    FWU_HECI,
    FWU_UNSUPPRT_PLAT,
    FWU_VERIFY_OEM_ID_ERR,
    FWU_INVALID_OEM_ID = 8745,
    FWU_INVALID_IMG_LENGTH,
    FWU_GLBL_BUFF_UNAVAILABLE,
    FWU_INVALID_FW_PARAMS,
    FWU_AMT_STATUS_INTERNAL_ERROR,
    FWU_AMT_STATUS_NOT_READY = 8750,
    FWU_AMT_STATUS_INVALID_AMT_MODE,
    FWU_AMT_STATUS_INVALID_MESSAGE_LENGTH,
    FWU_SAVE_RESTORE_POINT_ERROR,
    FWU_FILE_WRITE,
    FWU_GET_BLIST_ERROR = 8755,
    FWU_CHECK_VERSION_ERROR,
    FWU_DISPLAY_FW_VERSION,
    FWU_IMAGE_UNDER_VCN,
    FWU_IMAGE_VER_HIST_CHK_FAIL,
    FWU_DOWNGRADE_VETOED = 8760,
    FWU_FW_WRITE_FILE_FAIL,
    FWU_FW_READ_FILE_FAIL,
    FWU_FW_DELETE_FILE_FAIL,
    FWU_PARTITION_LAYOUT_NOT_COMP,
    FWU_DOWNGRADE_NOT_ALLOWED_DATA_MISMATCH = 8765,
    FWU_UPDATE_PASSWORD_NOT_MATCHED,
    FWU_UPDATE_PASSWORD_EXCEED_MAXIMUM_RETRY,
    FWU_UPDATE_PASSWORD_NOT_PROVIDED,
    FWU_UPDATE_POLLING_FAILED,
    FWU_FILE_ALREADY_EXISTS = 8770,
    FWU_FILE_INVALID,
    FWU_USAGE_ERROR_B,
    FWU_AUDIT_POLICY_FAILURE,
    FWU_ERROR_CREATING_FT,
    FWU_SAL_NOTIFICATION_ERROR = 8775,
    FWU_UPD_IMG_LOADING,
    FWU_UPD_IMG_AUTHENTICATING,
    FWU_UPD_IMG_PROCESSING,
    FWU_UPD_CREATING_FT,
    FWU_UPD_UPDATING_CODE,
    FWU_UPD_UPDATING_NFT,
    FWU_FLASH_CODE_PARTITION_INVALID,
    FWU_FLASH_NFT_PARTITION_INVALID,
    FWU_ILLEGAL_IMAGE_LENGTH,
    FWU_HOST_RESET_REQUIRED,
    FWU_INVALID_GLUT,
    FWU_GET_PATTRIB_ERROR,
    FWU_GET_UPD_INFO_STATUS,
    FWU_PID_NOT_EXPECTED,
    FWU_UPDATE_INRECOVERY_MODE_RESTRICT_UPDATE_TO_ATTEMPTED_VERSION,
    FWU_BUFFER_COPY_FAILED,
    FWU_GET_ME_FWU_INFO,
    FWU_APP_REGISTER_OS_FAILURE,
    FWU_APP_UNREGISTER_OS_FAILURE,
    FWU_INVALID_PARTID,
    FWU_LIVE_PING_FAILURE,
    FWU_SERVICE_CONNECT_FAILURE,
    FWU_SERVICE_NOT_AVAILABLE,
    FWU_SERVICE_BUSY,
    FWU_USER_NOT_ADMIN,
    FWU_WMI_FAIL,
    FWU_CHK_BIT_LOCKER_FAIL,
    FWU_REG_CMD_FAIL,
    FWU_UPDATE_IMAGE_BLACKLISTED,
    FWU_DOWNGRADE_NOT_ALLOWED_SVN_RESTRICTION,
    FWU_INVALID_POINTER,
    FWU_UPV_VERSION_MISMATCHED,
    FWU_INSTID_IS_NOT_EXPECTED_ID,
    FWU_INFO_NOT_AVAILABLE,
    FWU_REJ_IPU_FULL_UPDATE_NEEDED,
    FWU_IPU_NAMEID_NOT_FOUND,
    FWU_RESTORE_POINT_INVALID,
    FWU_RESTORE_POINT_VALID_BUT_NOT_LATEST,
    FWU_RESTORE_POINT_OPERATION_NOT_ALLOWED,
    FWU_DOWNGRADE_NOT_ALLOWED_VCN_RESTRICTION,
    FWU_INVALID_SVN,
    FWU_OUT_OF_SVN_RESOURCES,
    FWU_REJECT_RESTORE_POINT_REQUEST_FLASH_IN_RECOVERY,
    FWU_REJECTED_BY_UPDATE_POLICY,
    FWU_REJECTED_INCOMPATIBLE_TOOL_USAGE,
    FWU_REJECTED_CROSSPOINT_UPDATE_NOT_ALLOWED,
    FWU_REJECTED_CROSSHOTFIX_UPDATE_NOT_ALLOWED,
    FWU_REJECTED_CURRENT_FW_NOT_ELIGIBLE_FOR_UPDATE,
    FWU_REJECTED_WRONG_UPDATE_OPERATION,
    FWU_REJECTED_WRONG_UPDATE_IMAGE_FOUND,
    FWU_REJECTED_IFR_UPDATE_NOT_ALLOWED,
    FWU_FAILURE_OCCURRED_DURING_ROLLBACK,
    FWU_RESTORE_POINT_OPERATION_FAILED,
    FWU_ERROR_DETECT_POWER_SOURCE,
    FWU_DISPLAY_PART_VERSION,
    FWU_PART_NOT_PRESENT,
    FWU_ERROR_REQUEST_REPLY_SIZE_MISMATCH,
    FWU_UNSUPPRT_SKU_SLIM,
    FWU_REJECT_RESTORE_POINT_REQUEST_RESTART_NEEDED,
    FWU_ERROR_PMC_INSTANCE,
    FWU_ERROR_H_LP_MISMATCH,  
    FWU_ERROR_INIT_PMX,
    FWU_ERROR_REJECT_RESTORE_POINT_REQUEST_RESTART_NEEDED,
    FWU_ERROR_PMC_INSTANCE_MISMATCH,
    FWU_ERROR_UPD_IMG_TOO_BIG,
    FWU_ERROR_INVALID_MANIFEST_SIZE,
    FWU_ERROR_OPEN_LDR_VER_MAN_FAILED,
    FWU_ERROR_OPEN_LDR_KEYS_FAILED,
    FWU_ERROR_INSTALL_KEYS_FAILED,
    FWU_ERROR_UNINSTALL_KEYS_FAILED,
    FWU_ERROR_OPEN_LDR_INSTALL_FAILED,
    FWU_ERROR_INSTALL_FAILED,
    FWU_ERROR_PREUPDATE_VFS,
    FWU_ERROR_SPAWN_FAILED, 
    FWU_ERROR_WAITPID_FAILED,
    FWU_ERROR_PREUPDATE_FAILED,
    FWU_ERROR_SKUMGR_FAILED,
    FWU_ERROR_CFGMGR_FAILED,
    FWU_ERROR_MAN_NOT_FOUND,
    FWU_ERROR_CRYPTO_FAILED,
    FWU_ERROR_VER_MAN_FAILED_FTPR,
    FWU_ERROR_VER_MAN_FAILED_NFTP,
    FWU_ERROR_VER_MAN_FAILED_DLMP,
    FWU_ERROR_VER_MAN_FAILED_RBEP,
    FWU_ERROR_VER_MAN_FAILED_PMCP,
    FWU_ERROR_VER_MAN_FAILED_OEMP,
    FWU_ERROR_VER_MAN_FAILED_WCOD,
    FWU_ERROR_VER_MAN_FAILED_LOCL,
    FWU_ERROR_VER_MAN_FAILED_PAVP,
    FWU_ERROR_VER_MAN_FAILED_IOMP,
    FWU_ERROR_VER_MAN_FAILED_MGPP,
    FWU_ERROR_VER_MAN_FAILED_TBTP,
    FWU_ERROR_VER_MAN_FAILED_ISHC,
    FWU_ERROR_VER_MAN_FAILED_IUNP,
    FWU_ERROR_VER_MAN_FAILED_UPDT,
    FWU_ERROR_GET_EXT_FAILED_FTPR,
    FWU_ERROR_GET_EXT_FAILED_NFTP,
    FWU_ERROR_GET_EXT_FAILED_DLMP,
    FWU_ERROR_GET_EXT_FAILED_RBEP,
    FWU_ERROR_GET_EXT_FAILED_PMCP,
    FWU_ERROR_GET_EXT_FAILED_OEMP,
    FWU_ERROR_GET_EXT_FAILED_WCOD,
    FWU_ERROR_GET_EXT_FAILED_LOCL,
    FWU_ERROR_GET_EXT_FAILED_PAVP,
    FWU_ERROR_GET_EXT_FAILED_IOMP,
    FWU_ERROR_GET_EXT_FAILED_MGPP,
    FWU_ERROR_GET_EXT_FAILED_TBTP,
    FWU_ERROR_GET_EXT_FAILED_ISHC,
    FWU_ERROR_GET_EXT_FAILED_IUNP,
    FWU_ERROR_GET_EXT_FAILED_UPDT,
    FWU_ERROR_INTEGRITY_FAILED_FTPR,
    FWU_ERROR_INTEGRITY_FAILED_NFTP,
    FWU_ERROR_INTEGRITY_FAILED_DLMP,
    FWU_ERROR_INTEGRITY_FAILED_RBEP,
    FWU_ERROR_INTEGRITY_FAILED_PMCP,
    FWU_ERROR_INTEGRITY_FAILED_OEMP,
    FWU_ERROR_INTEGRITY_FAILED_WCOD,
    FWU_ERROR_INTEGRITY_FAILED_LOCL,
    FWU_ERROR_INTEGRITY_FAILED_PAVP,
    FWU_ERROR_INTEGRITY_FAILED_IOMP,
    FWU_ERROR_INTEGRITY_FAILED_MGPP,
    FWU_ERROR_INTEGRITY_FAILED_TBTP,
    FWU_ERROR_INTEGRITY_FAILED_ISHC,
    FWU_ERROR_INTEGRITY_FAILED_IUNP,
    FWU_ERROR_INTEGRITY_FAILED_UPDT,
    FWU_ERROR_PART_SIZE,
    FWU_ERROR_BACKUP_OUTSIDE_NFTP,
    FWU_ERROR_MAX_IUPS,
    FWU_ERROR_NOT_IUP,
    FWU_ERROR_IUP_MISSING_UPDATE,
    FWU_ERROR_PMC_MISSING_UPDATE,
    FWU_ERROR_NOT_PARTIAL_IUP,
    FWU_ERROR_PARTIAL_TCSS,
    FWU_ERROR_FTPR_VER,
    FWU_ERROR_FTPR_SVN,
    FWU_ERROR_FTPR_VCN,
    FWU_ERROR_FTPR_VER_MAJOR,
    FWU_ERROR_IUP_SVN,
    FWU_ERROR_IUP_VCN,
    FWU_ERROR_IMAGE_LEN,
    FWU_ERROR_PV_BIT,
    FWU_ERROR_REVENUE,
    FWU_ERROR_SVN_UPGRADE,
    FWU_ERROR_SVN_HOTFIX,
    FWU_ERROR_API_VER_MAJOR_FTPR,
    FWU_ERROR_API_VER_MAJOR_NFTP,
    FWU_ERROR_API_VER_MAJOR_DLMP,
    FWU_ERROR_API_VER_MAJOR_RBEP,
    FWU_ERROR_API_VER_MAJOR_PMCP,
    FWU_ERROR_API_VER_MAJOR_OEMP,
    FWU_ERROR_API_VER_MAJOR_WCOD,
    FWU_ERROR_API_VER_MAJOR_LOCL,
    FWU_ERROR_API_VER_MAJOR_PAVP,
    FWU_ERROR_API_VER_MAJOR_IOMP,
    FWU_ERROR_API_VER_MAJOR_MGPP,
    FWU_ERROR_API_VER_MAJOR_TBTP,
    FWU_ERROR_API_VER_MAJOR_ISHC,
    FWU_ERROR_API_VER_MAJOR_IUNP,
    FWU_ERROR_API_VER_MAJOR_UPDT,
    FWU_ERROR_IUP_MISSING_FLASH,
    FWU_ERROR_PARTITION_NOT_FOUND,
    FWU_ERROR_ENGINEERING_MISMATCH,
    FWU_ERROR_OEMP_MISSING,
    FWU_ERROR_IUPS_NOT_COMPATIBLE,
    FWU_ERROR_OEMP_IN_UPDATE,
    FWU_ERROR_WRONG_IUP,
    FWU_ERROR_IMAGE_IUP_SIZE,
    FWU_ERROR_OPEN_IUP,
    FWU_ERROR_SPI_IUP,
    FWU_ERROR_RULE_FILE_INVALID,
    FWU_ERROR_PWDMGR_FAILED,
    FWU_ERROR_PWR_FAILED,
    FWU_ERROR_SPI_FAILED,
    FWU_ERROR_RESTORE_POINT_ALREADY_STARTED,
    FWU_ERROR_RESTORE_POINT_OFFSET_INVALID,
    FWU_ERROR_WRONG_HECI_MSG_LENGTH,
    FWU_ERROR_ENV_INVALID,
    FWU_ERROR_WRONG_DATA_OPERATION,
    FWU_ERROR_DATA_LENGTH_INVALID,
    FWU_ERROR_WRONG_END_OPERATION,
    FWU_ERROR_FLUSH_NVM_ERR,
    FWU_ERROR_IPK_FAILURE,
    FWU_ERROR_PG_FAILURE,
    FWU_ERROR_INVALID_FLASH_IMAGE,
    FWU_ERROR_INVALID_UPDATE_IMAGE,
    FWU_ERROR_NO_IUP_IN_BASE_IMAGE,
    FWU_FILE_INVALID_MISSING_IUNP,
    FWU_FILE_INVALID_MISSING_ISHC,
    FWU_FILE_INVALID_MISSING_IUNP_IN_FLASH,
    FWU_FILE_INVALID_MISSING_ISHC_IN_FLASH,
    FWU_FILE_INVALID_MISSING_OEMP,
    FWU_FILE_INVALID_MISSING_OEMP_IN_FLASH,
    FWU_ERROR_GET_PLATFORM_TYPE,
    FWU_DISPLAY_PART_VENDOR_ID,
    FWU_INVALID_PARTID_ALL,
    FWU_ERROR_SVN_TCB_ARB,
    FWU_LAST_STATUS_CODE
};


#endif

